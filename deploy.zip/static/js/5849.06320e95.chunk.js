"use strict";(self.webpackChunkhub=self.webpackChunkhub||[]).push([[5849],{35849:(u,e,s)=>{s.r(e),s.d(e,{default:()=>h});const h={}}}]);
//# sourceMappingURL=5849.06320e95.chunk.js.map